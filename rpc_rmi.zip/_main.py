import sys
import time
import subprocess
from pathlib import Path

rpc_client_path = Path('./rpc_rmi/rpc_client.py')
rpc_server_path = Path('./rpc_rmi/rpc_server.py')
rmi_client_path = Path('./rpc_rmi/rmi_client.py')
rmi_server_path = Path('./rpc_rmi/rmi_server.py')


def main():
    if len(sys.argv) > 1:
        if sys.argv[1] == 'rpc':
            subprocess.Popen(['start', 'python', rpc_server_path], shell=True)
            time.sleep(3)
            subprocess.Popen(['start', 'python', rpc_client_path], shell=True)
            return
        elif sys.argv[1] == 'rmi':
            subprocess.Popen(['start', 'python', '-m', 'Pyro5.nameserver'], shell=True)
            time.sleep(5)
            subprocess.Popen(['start', 'python', rmi_server_path], shell=True)
            time.sleep(5)
            subprocess.Popen(['start', 'python', rmi_client_path], shell=True)
            return
        elif sys.argv[1] == 'del':
            subprocess.Popen(['del', '*.log'], shell=True)
    print('"rpc", "rmi" or "del"?')


if __name__ == '__main__':
    main()